"""UNEXECUTED ordinary AC probe+real parser source. No production entrypoint."""
import base64,json,os,sys,ctypes,socket
from datetime import date,datetime
from pathlib import Path

class Refused(RuntimeError):pass

def denied_open(path,rights):
    k=ctypes.WinDLL('kernel32',use_last_error=True)
    k.CreateFileW.argtypes=(ctypes.c_wchar_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p,ctypes.c_uint32,ctypes.c_uint32,ctypes.c_void_p)
    k.CreateFileW.restype=ctypes.c_void_p;k.CloseHandle.argtypes=(ctypes.c_void_p,);k.CloseHandle.restype=ctypes.c_int
    h=k.CreateFileW(str(path),rights,7,None,3,0x00200000,None)
    if h==ctypes.c_void_p(-1).value:
        error=ctypes.get_last_error()
        if error!=5:raise Refused('negative open not access denied: '+str(error))
        return 'access-denied'
    if not k.CloseHandle(h):raise Refused('unexpected-grant handle close failed')
    raise Refused('negative open unexpectedly granted')

def network_probe(family,address):
    # Only already-listening synthetic loopback endpoints, never DNS/LAN/internet.
    # Connection refusal/timeout is not an isolation pass. Unexpected success fails.
    s=None
    try:
        s=socket.socket(family,socket.SOCK_STREAM);s.settimeout(.25);s.connect(address)
    except OSError as exc:
        if getattr(exc,'winerror',None)!=10013:raise Refused('network denial not WSAEACCES') from exc
        return 'wsaeacces'
    else:raise Refused('synthetic loopback unexpectedly reachable')
    finally:
        if s is not None:s.close()

def probe(config):
    if set(config)!={'secret','runtime_file','package_path','loopback4','loopback6'}:raise Refused('fixed probe config')
    out={}
    for label,rights in (('secret-read',0x80000000),('secret-write',0x40000000),('secret-delete',0x10000),('secret-dacl',0x40000)):
        out[label]=denied_open(config['secret'],rights)
    # Positive runtime readability and file hash occurs trusted side before launch.
    if not Path(config['runtime_file']).read_bytes():raise Refused('runtime positive read failed')
    for label,rights in (('runtime-write',0x40000000),('runtime-delete',0x10000),('runtime-dacl',0x40000)):
        out[label]=denied_open(config['runtime_file'],rights)
    out['loopback4']=network_probe(socket.AF_INET,('127.0.0.1',config['loopback4']))
    out['loopback6']=network_probe(socket.AF_INET6,('::1',config['loopback6']))
    # Writable package storage is measured and cleaned, never denied by assertion.
    p=Path(config['package_path'])/'hony-synthetic-storage-probe.txt'
    if p.exists():raise Refused('package probe collision')
    fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    try:os.write(fd,b'SYNTHETIC-NOT-EXECUTABLE');os.fsync(fd)
    finally:os.close(fd)
    try:
        if p.read_bytes()!=b'SYNTHETIC-NOT-EXECUTABLE':raise Refused('package probe bytes')
    finally:p.unlink()
    out['package-write-read-delete']='observed'
    return out

def main():
    if os.name!='nt':raise Refused('Windows candidate only')
    config=json.loads(Path(__file__).with_name('PROBE.json').read_text())
    measured=probe(config)
    from app.fingerprint_evidence import parse_fingerprint_evidence
    raw=sys.stdin.buffer.read(16_000_001)
    if len(raw)>16_000_000:raise Refused('input budget')
    v=json.loads(raw)
    if type(v) is not dict or set(v)!={'payload','filename','aliases'}:raise Refused('request schema')
    result=parse_fingerprint_evidence(base64.b64decode(v['payload'],validate=True),filename=v['filename'],verified_aliases=v['aliases'])
    result=dict(status='ok',period_start=result.period_start,period_end=result.period_end,occurrences=[dict(x) for x in result.occurrences],issues=[dict(x) for x in result.issues])
    def serial(x):
        if type(x) in (date,datetime):return x.isoformat()
        raise TypeError('result scalar')
    encoded=json.dumps(dict(measurements=measured,parser=result),default=serial,allow_nan=False,separators=(',',':')).encode()
    if len(encoded)>4_000_000:raise Refused('output budget')
    sys.stdout.buffer.write(encoded)
if __name__=='__main__':main()
