# SOURCE ONLY. No workflow installed. Explicit future reviewed one-attempt scope.
param([Parameter(Mandatory=$true)][string]$ProductRoot,[Parameter(Mandatory=$true)][string]$TrustedPython)
$ErrorActionPreference='Stop'
if($env:GITHUB_ACTIONS -ne 'true'){throw 'Disposable CI only'}
# Invoker verifies package archive pin BEFORE this script. Inside, verify every source pin.
$pins=Get-Content "$PSScriptRoot/SHA256.json" -Raw|ConvertFrom-Json
foreach($prop in $pins.PSObject.Properties){
 $path=Join-Path $PSScriptRoot $prop.Name
 if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower() -ne $prop.Value){throw 'Exact source mismatch'}
}
$build=Join-Path $env:RUNNER_TEMP 'HOnYOrdinaryAC1116-build'
if(Test-Path -LiteralPath $build){throw 'Build collision preserved'}
New-Item -ItemType Directory $build|Out-Null
$complete=$false
try {
 & cl.exe /nologo /W4 /O2 /DUNICODE /D_UNICODE "$PSScriptRoot/launcher.c" /Fe:"$build/launcher.exe" /Fo:"$build/launcher.obj" /link userenv.lib advapi32.lib
 if($LASTEXITCODE -ne 0){throw 'Native compile failed'}
 & $TrustedPython -I "$PSScriptRoot/acquire_locked.py" --lock "$PSScriptRoot/ACQUISITION-LOCK.json" --destination "$build/acquired"
 if($LASTEXITCODE -ne 0){throw 'Acquisition failed'}
 & $TrustedPython -I "$PSScriptRoot/run.py" $ProductRoot "$build/acquired" "$build/launcher.exe"
 if($LASTEXITCODE -ne 0){throw 'Candidate refused, preserve diagnostics/profile if cleanup unknown'}
 $complete=$true
} finally {
 # Bounded source acquisition/build tree retained on unknown outcome, never broad cleanup.
 if($complete){Remove-Item -LiteralPath $build -Recurse; if(Test-Path -LiteralPath $build){throw 'Build cleanup failed'}}
}
