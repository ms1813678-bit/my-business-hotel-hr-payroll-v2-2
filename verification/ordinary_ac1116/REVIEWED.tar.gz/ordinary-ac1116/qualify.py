"""UNEXECUTED fixed candidate. Only disposable CI, never imports product parser in host."""
import base64,ctypes,hashlib,json,os,pathlib,secrets,socket,subprocess,sys,threading,time,uuid
import win32security as sec,win32api,win32con,win32file,pywintypes
from stage_runtime import stage

PROFILE='HOnY.OrdinaryAC1116.'+uuid.uuid4().hex

class Refused(RuntimeError):pass

def acl(path,sid=None):
    suffix='' if sid is None else '(A;OICI;GRGX;;;'+sid+')'
    isdir=path.is_dir();inherit='OICI' if isdir else ''
    me=sec.ConvertSidToStringSid(sec.GetTokenInformation(sec.OpenProcessToken(win32api.GetCurrentProcess(),sec.TOKEN_QUERY),sec.TokenUser)[0])
    sddl='O:'+me+'G:BAD:P'+''.join('(A;'+inherit+';FA;;;'+s+')' for s in (me,'SY','BA'))
    if sid is not None:sddl+='(A;'+inherit+';GRGX;;;'+sid+')'
    sd=sec.ConvertStringSecurityDescriptorToSecurityDescriptor(sddl,1)
    sec.SetFileSecurity(str(path),sec.OWNER_SECURITY_INFORMATION|sec.DACL_SECURITY_INFORMATION|sec.PROTECTED_DACL_SECURITY_INFORMATION,sd)
    check=sec.GetFileSecurity(str(path),sec.OWNER_SECURITY_INFORMATION|sec.DACL_SECURITY_INFORMATION)
    # Compare normalized ACE tuples/SIDs/owner against the intended descriptor.
    def shape(d):
        a=d.GetSecurityDescriptorDacl();return sec.ConvertSidToStringSid(d.GetSecurityDescriptorOwner()),[(a.GetAce(i)[0],a.GetAce(i)[1],sec.ConvertSidToStringSid(a.GetAce(i)[2])) for i in range(a.GetAceCount())]
    if shape(check)!=shape(sd) or not check.GetSecurityDescriptorControl()[0]&sec.SE_DACL_PROTECTED:raise Refused('ACL readback differs')

def exact_output(raw,aliases,decode):
    if not isinstance(raw,bytes) or len(raw)>4_000_000:raise Refused('output budget')
    def pairs(rows):
        d={}
        for k,v in rows:
            if k in d:raise Refused('duplicate key')
            d[k]=v
        return d
    v=json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(Refused('nonfinite')))
    if type(v) is not dict or set(v)!={'measurements','parser'}:raise Refused('measurement envelope')
    expected={**{k:'access-denied' for k in ('secret-read','secret-write','secret-delete','secret-dacl','runtime-write','runtime-delete','runtime-dacl')},'loopback4':'wsaeacces','loopback6':'wsaeacces','package-write-read-delete':'observed'}
    if v['measurements']!=expected:raise Refused('measurement result mismatch')
    return decode(json.dumps(v['parser'],allow_nan=False,separators=(',',':')).encode(),aliases),v['measurements']

def main():
    if sys.platform!='win32' or os.environ.get('GITHUB_ACTIONS')!='true' or len(sys.argv)!=4:raise Refused('fixed disposable CI only')
    # repo, acquired directory and compiled launcher are the reviewed owning workflow inputs.
    repo,acquired,launcher=map(lambda x:pathlib.Path(x).resolve(strict=True),sys.argv[1:])
    root=pathlib.Path(os.environ['RUNNER_TEMP'])/'HOnYOrdinaryAC1116'
    if root.exists() or root.is_symlink():raise Refused('fixed root collision')
    root.mkdir();identity=root.stat();marker=secrets.token_hex(16);(root/'OWNER').write_text(marker)
    userenv=ctypes.WinDLL('userenv',use_last_error=True);ole=ctypes.WinDLL('ole32')
    userenv.CreateAppContainerProfile.argtypes=(ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_wchar_p,ctypes.c_void_p,ctypes.c_uint32,ctypes.POINTER(ctypes.c_void_p));userenv.CreateAppContainerProfile.restype=ctypes.c_long
    userenv.DeleteAppContainerProfile.argtypes=(ctypes.c_wchar_p,);userenv.DeleteAppContainerProfile.restype=ctypes.c_long
    userenv.GetAppContainerFolderPath.argtypes=(ctypes.c_wchar_p,ctypes.POINTER(ctypes.c_void_p));userenv.GetAppContainerFolderPath.restype=ctypes.c_long
    ctypes.windll.advapi32.FreeSid.argtypes=(ctypes.c_void_p,);ctypes.windll.advapi32.FreeSid.restype=ctypes.c_void_p
    ole.CoTaskMemFree.argtypes=(ctypes.c_void_p,);ole.CoTaskMemFree.restype=None
    safe_cleanup=True;created=False;sidptr=ctypes.c_void_p();folderptr=ctypes.c_void_p();listeners=[];procs=[];failures=[];results=[];package=None
    try:
        hr=userenv.CreateAppContainerProfile(PROFILE,PROFILE,'Synthetic1116only',None,0,ctypes.byref(sidptr))
        if hr:raise Refused('profile exclusive create failed '+str(hr))
        created=True
        textptr=ctypes.c_void_p();advapi=ctypes.WinDLL('advapi32',use_last_error=True);kernel=ctypes.WinDLL('kernel32',use_last_error=True)
        advapi.ConvertSidToStringSidW.argtypes=(ctypes.c_void_p,ctypes.POINTER(ctypes.c_void_p));advapi.ConvertSidToStringSidW.restype=ctypes.c_int
        kernel.LocalFree.argtypes=(ctypes.c_void_p,);kernel.LocalFree.restype=ctypes.c_void_p
        if not advapi.ConvertSidToStringSidW(sidptr,ctypes.byref(textptr)):raise Refused('sid conversion')
        try:sid=ctypes.wstring_at(textptr)
        finally:
            if kernel.LocalFree(textptr):raise Refused('sid string free')
        if userenv.GetAppContainerFolderPath(sid,ctypes.byref(folderptr)):raise Refused('package location failed')
        package=pathlib.Path(ctypes.wstring_at(folderptr));ole.CoTaskMemFree(folderptr);folderptr=ctypes.c_void_p()
        local=package/'LocalState'
        if not local.exists():local.mkdir()
        if (local/'hony-synthetic-storage-probe.txt').exists():raise Refused('package canary collision')
        dest=root/'stage';packages={n:acquired/'packages'/n for n in ('openpyxl','xlrd','et_xmlfile')}
        stage(acquired/'runtime',repo,packages,dest)
        runtime=dest/'runtime';secret=root/'secret.txt';secret.write_bytes(b'SYNTHETIC-SECRET-1116')
        acl(secret)
        for p in [runtime,*runtime.rglob('*')]:
            if p.is_symlink():raise Refused('reparse stage')
            acl(p,sid)
        # Allow fixed app package traversal only on this newly owned root/stage.
        acl(root,sid);acl(dest,sid)
        for family,address in ((socket.AF_INET,('127.0.0.1',0)),(socket.AF_INET6,('::1',0))):
            sock=socket.socket(family,socket.SOCK_STREAM);sock.bind(address);sock.listen(3);sock.settimeout(.1);listeners.append(sock)
            control=socket.socket(family,socket.SOCK_STREAM);control.settimeout(.5);control.connect(sock.getsockname());accepted,_=sock.accept();accepted.close();control.close()
        config=dict(secret=str(secret),runtime_file=str(runtime/'candidate_worker.py'),package_path=str(local),loopback4=listeners[0].getsockname()[1],loopback6=listeners[1].getsockname()[1])
        # Replace only candidate probe worker/config before pinning final inventory.
        (runtime/'candidate_worker.py').write_bytes(pathlib.Path(__file__).with_name('candidate_worker.py').read_bytes())
        (runtime/'PROBE.json').write_text(json.dumps(config));acl(runtime/'candidate_worker.py',sid);acl(runtime/'PROBE.json',sid)
        hashes={str(p.relative_to(runtime)):hashlib.sha256(p.read_bytes()).hexdigest() for p in runtime.rglob('*') if p.is_file()}
        pins=json.loads(pathlib.Path(__file__).with_name('PRODUCT-SHA256.json').read_text())
        for name,pin in pins.items():
            if hashlib.sha256((repo/name).read_bytes()).hexdigest()!=pin:raise Refused('product source pin')
        sys.path.insert(0,str(repo));from app.fingerprint_bounded_parse import _decode_worker
        for suffix in ('xls','xlsx'):
            data=pathlib.Path(__file__).with_name('synthetic.'+suffix).read_bytes();request=json.dumps(dict(payload=base64.b64encode(data).decode(),filename='synthetic.'+suffix,aliases={'SYN':1})).encode()
            command=[str(launcher),PROFILE,str(runtime/'python.exe'),str(runtime),str(runtime/'candidate_worker.py')]
            broker=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env={'SYSTEMROOT':os.environ['SYSTEMROOT'],'LOCALAPPDATA':os.environ['LOCALAPPDATA']})
            try:stdout,stderr=broker.communicate(request,timeout=8)
            except subprocess.TimeoutExpired:
                safe_cleanup=False;broker.kill();broker.wait(timeout=3);raise Refused('broker timeout; child absence unknown; preserve profile/stage')
            p=subprocess.CompletedProcess(command,broker.returncode,stdout,stderr)
            if b'CANDIDATE_CLEANUP complete=1' not in stderr:safe_cleanup=False;raise Refused('native cleanup unconfirmed; preserve profile/stage')
            if p.returncode or len(p.stderr)>65536:raise Refused('broker failed: '+p.stderr[:4096].decode('ascii',errors='replace'))
            parsed,measured=exact_output(p.stdout,{'SYN':1},_decode_worker)
            first,last,events,issues=parsed
            if len(events)!=4 or events[0]['employee_id'] is not None or events[1]['punch_at']!=events[2]['punch_at']:raise Refused('parse parity')
            if secret.read_bytes()!=b'SYNTHETIC-SECRET-1116':raise Refused('secret changed')
            now={str(q.relative_to(runtime)):hashlib.sha256(q.read_bytes()).hexdigest() for q in runtime.rglob('*') if q.is_file()}
            if now!=hashes:raise Refused('runtime changed')
            if (local/'hony-synthetic-storage-probe.txt').exists():raise Refused('package probe persists')
            results.append(dict(format=suffix,measurements=measured,occurrences=len(events),runtime_unchanged=True,secret_unchanged=True))
    except BaseException as e:failures.append(type(e).__name__+':'+str(e))
    finally:
        for sock in listeners:
            try:sock.close()
            except BaseException as e:failures.append('listener-close:'+type(e).__name__)
        if folderptr.value:ole.CoTaskMemFree(folderptr)
        if sidptr.value and ctypes.windll.advapi32.FreeSid(sidptr):failures.append('sid-free')
        if created and safe_cleanup:
            hr=userenv.DeleteAppContainerProfile(PROFILE)
            if hr:failures.append('profile-delete:'+str(hr))
            elif package is not None and package.exists():failures.append('package-directory-preserved-or-still-present')
        # No forced deletion on failure/unknown. Success removes only unchanged owned source tree.
        if created and not safe_cleanup:failures.append('unsafe-child-absence-profile-preserved')
        if not failures:
            import shutil
            st=root.lstat()
            if root.is_symlink() or (st.st_dev,st.st_ino)!=(identity.st_dev,identity.st_ino) or (root/'OWNER').read_text()!=marker:failures.append('root-ownership')
            else:shutil.rmtree(root)
        print(json.dumps(dict(status='measurement-only',product_activated=False,results=results,failures=failures,root_absent=not root.exists(),remaining_gates=['sharedIPC','networkbeyondloopback','adversarialresourceexecution','productionsecretACLs'])),flush=True)
    return 1 if failures else 0
if __name__=='__main__':raise SystemExit(main())
