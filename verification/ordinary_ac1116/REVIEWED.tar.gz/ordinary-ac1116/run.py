"""Fixed trusted bootstrap allows sibling imports under -I, not working-directory imports."""
import pathlib,sys
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parent))
from qualify import main
raise SystemExit(main())
